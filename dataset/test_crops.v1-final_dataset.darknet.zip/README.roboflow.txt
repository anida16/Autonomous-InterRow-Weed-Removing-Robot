
test_crops - v1 final_dataset
==============================

This dataset was exported via roboflow.ai on March 17, 2021 at 9:21 AM GMT

It includes 358 images.
Testcrops are annotated in YOLO v3 Darknet format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* Random brigthness adjustment of between -12 and +12 percent
* Random Gaussian blur of between 0 and 1 pixels


